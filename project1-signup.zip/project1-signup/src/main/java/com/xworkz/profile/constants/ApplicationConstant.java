package com.xworkz.profile.constants;

public class ApplicationConstant {
	
	public final static String SUCCESS="success";
	public final static String  SUCCESSMSG="Account created Successfully";
	
	public final static String REPEAT="repeat";
	public final static String REPEATMSG="Account is not created";
	public final static String REPEATMSGERR="Account not created bcz already acount is exist";

	public final static String PROFILE="log";
	public final static String PROFILEMSG="Login Succesfull";
	public final static String PROFILEERR="Login Failed";


	
}
