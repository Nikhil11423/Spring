//package com.xworkz.profile.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.RequestMapping;
//
//import com.xworkz.profile.entity.ProfileEntity;
//import com.xworkz.profile.service.ProfileService;
//
//@Component
//@RequestMapping("/")
//public class UpdateController {
//	
//	@Autowired
//	private ProfileService service; 
//	
//	public UpdateController() {
//     System.out.println("update controller");	
// }
//
////	@RequestMapping("/up")
////	public String onfullname(ProfileEntity entity,Model model) {
////		ProfileEntity ent =service.updateProfileEntityByUserId(entity.getUserId(),entity.getFullName() );
////		model.addAttribute("data", entity);
////		return "update";
////	}
//}
