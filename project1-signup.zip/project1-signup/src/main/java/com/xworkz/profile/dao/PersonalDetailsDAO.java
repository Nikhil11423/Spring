//package com.xworkz.profile.dao;
//
//import com.xworkz.profile.personal.PersonalEntity;
//
//public interface PersonalDetailsDAO {
//
//    boolean save(PersonalEntity personalEntity);
//}
